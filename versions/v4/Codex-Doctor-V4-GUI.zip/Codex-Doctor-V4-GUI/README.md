# Codex Doctor V4 — GUI

Windows 图形界面版本。

主要功能：
- 一键诊断 Codex / ChatGPT Desktop。
- 自动读取 Windows 系统代理。
- 自动搜索 Clash Verge / Clash Verge Rev / Mihomo 常见配置。
- 解析 mixed-port / port / socks-port。
- 测试候选端口是否监听。
- 使用候选 HTTP 代理测试 ChatGPT / OpenAI HTTPS 连通性。
- 自动修改 `%USERPROFILE%\.codex\.env`。
- 自动写入当前用户 HTTP_PROXY / HTTPS_PROXY。
- 一键迁移 `%USERPROFILE%\.codex` 到 D/E 盘。
- 使用 NTFS Junction 保持 Codex 原路径兼容。
- 自动备份，一键恢复。
- 可调用官方 `codex doctor`（CLI 存在时）。

## 使用方式
双击：

`启动_Codex_Doctor_V4.bat`

推荐顺序：

1. 一键诊断
2. 一键修复 Reconnecting
3. 如需释放 C 盘空间，再迁移 `.codex`
4. 修改 `.env` 后彻底退出并重新打开 ChatGPT/Codex Desktop

## 默认迁移位置
`D:\Codex\.codex`

## 安全说明
本工具不会移动或修改 WindowsApps/MSIX 应用包本体。
迁移仅针对用户数据目录 `.codex`。
