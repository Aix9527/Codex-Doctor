﻿#requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$CodexDir = Join-Path $env:USERPROFILE ".codex"
$StateRoot = Join-Path $env:LOCALAPPDATA "CodexDoctorV4"
$StateFile = Join-Path $StateRoot "state.json"
$LogDir = Join-Path $StateRoot "logs"
New-Item -ItemType Directory -Force -Path $StateRoot,$LogDir | Out-Null
$LogFile = Join-Path $LogDir ("doctor-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".log")

function Add-Log([string]$Text) {
    $line = "[$(Get-Date -Format HH:mm:ss)] $Text"
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    if ($script:LogBox) {
        $script:LogBox.AppendText($line + [Environment]::NewLine)
        $script:LogBox.SelectionStart = $script:LogBox.Text.Length
        $script:LogBox.ScrollToCaret()
        [System.Windows.Forms.Application]::DoEvents()
    }
}

function Test-Port([int]$Port) {
    try {
        $c = New-Object Net.Sockets.TcpClient
        $ar = $c.BeginConnect("127.0.0.1",$Port,$null,$null)
        $ok = $ar.AsyncWaitHandle.WaitOne(350)
        if($ok -and $c.Connected){$c.EndConnect($ar);$c.Close();return $true}
        $c.Close()
    } catch {}
    return $false
}

function Get-ListenerProcess([int]$Port) {
    try {
        $x = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop | Select-Object -First 1
        if($x){
            $p = Get-Process -Id $x.OwningProcess -ErrorAction SilentlyContinue
            if($p){return $p.ProcessName}
        }
    } catch {}
    return ""
}

function Get-SystemProxy {
    try {
        $k = Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        [pscustomobject]@{
            Enabled=[bool]$k.ProxyEnable
            Server=$k.ProxyServer
            AutoConfigURL=$k.AutoConfigURL
        }
    } catch {
        [pscustomobject]@{Enabled=$false;Server="";AutoConfigURL=""}
    }
}

function Find-ClashConfigs {
    $roots=@(
        (Join-Path $env:APPDATA "io.github.clash-verge-rev.clash-verge-rev"),
        (Join-Path $env:APPDATA "clash-verge"),
        (Join-Path $env:APPDATA "Clash Verge"),
        (Join-Path $env:APPDATA "mihomo-party"),
        (Join-Path $env:USERPROFILE ".config\clash"),
        (Join-Path $env:USERPROFILE ".config\mihomo")
    ) | Where-Object {$_ -and (Test-Path $_)}

    $files=@()
    foreach($r in $roots){
        try {
            $files += Get-ChildItem $r -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object {$_.Extension -in @(".yaml",".yml",".json")} |
                Select-Object -First 100
        } catch {}
    }
    $files
}

function Get-ProxyPortsFromConfig {
    $ports=@()
    foreach($f in Find-ClashConfigs){
        try {
            $txt=Get-Content $f.FullName -Raw
            foreach($key in @("mixed-port","port","socks-port")){
                foreach($x in [regex]::Matches($txt,"(?im)^\s*"+[regex]::Escape($key)+"\s*:\s*(\d+)")){
                    $ports += [pscustomobject]@{Port=[int]$x.Groups[1].Value;Source="$key | $($f.FullName)"}
                }
            }
        } catch {}
    }
    $ports | Sort-Object Port -Unique
}

function Test-HttpProxy([int]$Port) {
    foreach($u in @("https://chatgpt.com","https://api.openai.com")){
        try {
            $r = Invoke-WebRequest -Uri $u -Proxy "http://127.0.0.1:$Port" -Method Head -TimeoutSec 6 -UseBasicParsing
            if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){return $true}
        } catch {
            try {
                if($_.Exception.Response){
                    $code=[int]$_.Exception.Response.StatusCode
                    if($code -ge 400 -and $code -lt 500){return $true}
                }
            } catch {}
        }
    }
    return $false
}

function Get-ProxyCandidates {
    $raw=@()
    $sys=Get-SystemProxy

    if($sys.Enabled -and $sys.Server){
        foreach($m in [regex]::Matches($sys.Server,'(?:127\.0\.0\.1|localhost):(\d+)')){
            $raw += [pscustomobject]@{Port=[int]$m.Groups[1].Value;Source="Windows system proxy"}
        }
    }

    $raw += @(Get-ProxyPortsFromConfig)
    foreach($p in @(7897,7890,7891,10809,10808,1080,20171,20170)){
        $raw += [pscustomobject]@{Port=$p;Source="Common port scan"}
    }

    $seen=@{}
    $out=@()
    foreach($x in $raw){
        if($seen.ContainsKey($x.Port)){continue}
        $seen[$x.Port]=$true
        if(Test-Port $x.Port){
            $out += [pscustomobject]@{
                Port=$x.Port
                Source=$x.Source
                Process=(Get-ListenerProcess $x.Port)
                HttpOk=(Test-HttpProxy $x.Port)
            }
        }
    }
    $out | Sort-Object @{Expression="HttpOk";Descending=$true},Port
}

function Select-BestProxy {
    $c=@(Get-ProxyCandidates)
    if($c.Count -eq 0){return $null}
    $ok=@($c|Where-Object {$_.HttpOk})
    if($ok.Count){return $ok[0]}
    return $c[0]
}

function Backup-File([string]$Path){
    if(Test-Path $Path){
        $b="$Path.backup_$(Get-Date -Format yyyyMMdd_HHmmss)"
        Copy-Item $Path $b -Force
        return $b
    }
}

function Get-CodexProcesses {
    Get-Process -ErrorAction SilentlyContinue | Where-Object {
        $_.ProcessName -match 'Codex|ChatGPT' -or ($_.Path -and $_.Path -match 'Codex|ChatGPT')
    }
}

function Stop-CodexProcesses {
    $p=@(Get-CodexProcesses)
    if($p.Count){
        Add-Log "Closing Codex/ChatGPT related processes..."
        $p | Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 800
    }
}

function Write-CodexProxy {
    $p=Select-BestProxy
    if(-not $p){throw "No active local proxy found."}

    Add-Log "Selected proxy: 127.0.0.1:$($p.Port) | process=$($p.Process) | HTTP-test=$($p.HttpOk)"
    if(-not(Test-Path $CodexDir)){New-Item -ItemType Directory -Force -Path $CodexDir|Out-Null}

    $envfile=Join-Path $CodexDir ".env"
    $backup=Backup-File $envfile
    if($backup){Add-Log "Backup created: $backup"}

    $old=@()
    if(Test-Path $envfile){$old=Get-Content $envfile -ErrorAction SilentlyContinue}
    $filtered=$old | Where-Object {
        $_ -notmatch '^\s*(HTTP_PROXY|HTTPS_PROXY|http_proxy|https_proxy|ALL_PROXY|all_proxy|NO_PROXY|no_proxy)\s*='
    }

    $url="http://127.0.0.1:$($p.Port)"
    $lines=@()
    if($filtered){$lines+=$filtered;$lines+=""}
    $lines+=@(
        "# Managed by Codex Doctor V4 GUI",
        "HTTP_PROXY=$url",
        "HTTPS_PROXY=$url",
        "http_proxy=$url",
        "https_proxy=$url",
        "NO_PROXY=localhost,127.0.0.1,::1",
        "no_proxy=localhost,127.0.0.1,::1"
    )
    Set-Content $envfile $lines -Encoding UTF8

    foreach($n in @("HTTP_PROXY","HTTPS_PROXY","http_proxy","https_proxy")){
        [Environment]::SetEnvironmentVariable($n,$url,"User")
    }
    foreach($n in @("NO_PROXY","no_proxy")){
        [Environment]::SetEnvironmentVariable($n,"localhost,127.0.0.1,::1","User")
    }

    Add-Log "Updated: $envfile"
    return $p
}

function Save-State($o){$o|ConvertTo-Json -Depth 5|Set-Content $StateFile -Encoding UTF8}
function Load-State {if(Test-Path $StateFile){Get-Content $StateFile -Raw|ConvertFrom-Json}else{$null}}

function Migrate-Codex([string]$Root){
    Stop-CodexProcesses
    New-Item -ItemType Directory -Force -Path $Root|Out-Null
    $target=Join-Path $Root ".codex"

    if(Test-Path $CodexDir){
        $i=Get-Item $CodexDir -Force
        if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw "Codex directory is already linked."}
    }

    if((Test-Path $target) -and @(Get-ChildItem $target -Force -ErrorAction SilentlyContinue).Count -gt 0){
        throw "Target is not empty: $target"
    }

    New-Item -ItemType Directory -Force -Path $target|Out-Null
    $backup=$null

    if(Test-Path $CodexDir){
        Add-Log "Copying $CodexDir => $target"
        & robocopy $CodexDir $target /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /XJ /NFL /NDL /NP | Out-Null
        if($LASTEXITCODE -ge 8){throw "Robocopy failed: $LASTEXITCODE"}
        $backup="$CodexDir.pre-migrate-$(Get-Date -Format yyyyMMdd-HHmmss)"
        Move-Item $CodexDir $backup
    }

    cmd.exe /c "mklink /J `"$CodexDir`" `"$target`"" | Out-Null
    if(-not(Test-Path $CodexDir)){
        if($backup -and(Test-Path $backup)){Move-Item $backup $CodexDir}
        throw "Failed to create NTFS Junction."
    }

    Save-State ([ordered]@{source=$CodexDir;target=$target;backup=$backup;migrated_at=(Get-Date).ToString("o")})
    Add-Log "Migration complete: $CodexDir => $target"
}

function Restore-Codex {
    Stop-CodexProcesses
    $s=Load-State
    if(-not $s){throw "No migration state found."}

    if(Test-Path $s.source){
        $i=Get-Item $s.source -Force
        if(-not($i.Attributes -band [IO.FileAttributes]::ReparsePoint)){throw "Source is not a Junction; aborting for safety."}
        cmd.exe /c "rmdir `"$($s.source)`"" | Out-Null
    }

    if($s.backup -and(Test-Path $s.backup)){
        Move-Item $s.backup $s.source
    } else {
        New-Item -ItemType Directory -Force -Path $s.source|Out-Null
    }

    if(Test-Path $s.target){
        & robocopy $s.target $s.source /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /XJ /NFL /NDL /NP | Out-Null
    }

    Remove-Item $StateFile -Force -ErrorAction SilentlyContinue
    Add-Log "Restore complete."
}

function Run-CodexDoctor {
    try {
        $null=Get-Command codex -ErrorAction Stop
        Add-Log "Running official codex doctor..."
        $out = & codex doctor 2>&1 | Out-String
        Add-Log $out.Trim()
    } catch {
        Add-Log "Codex CLI not found in PATH; official codex doctor skipped."
    }
}

function Update-Status {
    $script:LblCodex.Text="Codex 数据：正在检查..."
    $script:LblProxy.Text="代理：正在检查..."
    $script:LblConn.Text="连通性：正在检查..."
    [System.Windows.Forms.Application]::DoEvents()

    if(Test-Path $CodexDir){
        $i=Get-Item $CodexDir -Force
        if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){
            $script:LblCodex.Text="Codex 数据：已迁移 → " + ($i.Target -join ", ")
        } else {
            $script:LblCodex.Text="Codex 数据：" + $CodexDir
        }
    } else {
        $script:LblCodex.Text="Codex 数据：尚未创建"
    }

    $p=Select-BestProxy
    if($p){
        $script:LblProxy.Text="代理：127.0.0.1:$($p.Port)  [$($p.Process)]"
        $script:LblConn.Text="连通性：" + $(if($p.HttpOk){"通过"}else{"端口监听，但 HTTP 测试未通过"})
    } else {
        $script:LblProxy.Text="代理：未检测到"
        $script:LblConn.Text="连通性：不可用"
    }
}

$form = New-Object System.Windows.Forms.Form
$form.Text = "Codex Doctor V4 — GUI"
$form.Size = New-Object System.Drawing.Size(900,680)
$form.StartPosition = "CenterScreen"
$form.MinimumSize = New-Object System.Drawing.Size(820,620)

$title = New-Object System.Windows.Forms.Label
$title.Text = "Codex Doctor V4"
$title.Font = New-Object System.Drawing.Font("Segoe UI",20,[System.Drawing.FontStyle]::Bold)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(26,20)
$form.Controls.Add($title)

$sub = New-Object System.Windows.Forms.Label
$sub.Text = "Codex / ChatGPT Desktop · 代理修复 · .codex 迁移 · 回滚"
$sub.Font = New-Object System.Drawing.Font("Segoe UI",10)
$sub.AutoSize = $true
$sub.Location = New-Object System.Drawing.Point(30,60)
$form.Controls.Add($sub)

$script:LblCodex = New-Object System.Windows.Forms.Label
$script:LblCodex.Location = New-Object System.Drawing.Point(30,100)
$script:LblCodex.Size = New-Object System.Drawing.Size(820,26)
$form.Controls.Add($script:LblCodex)

$script:LblProxy = New-Object System.Windows.Forms.Label
$script:LblProxy.Location = New-Object System.Drawing.Point(30,128)
$script:LblProxy.Size = New-Object System.Drawing.Size(820,26)
$form.Controls.Add($script:LblProxy)

$script:LblConn = New-Object System.Windows.Forms.Label
$script:LblConn.Location = New-Object System.Drawing.Point(30,156)
$script:LblConn.Size = New-Object System.Drawing.Size(820,26)
$form.Controls.Add($script:LblConn)

$targetLabel = New-Object System.Windows.Forms.Label
$targetLabel.Text = "迁移目标："
$targetLabel.Location = New-Object System.Drawing.Point(30,194)
$targetLabel.Size = New-Object System.Drawing.Size(80,25)
$form.Controls.Add($targetLabel)

$targetBox = New-Object System.Windows.Forms.TextBox
$targetBox.Text = "D:\Codex"
$targetBox.Location = New-Object System.Drawing.Point(110,191)
$targetBox.Size = New-Object System.Drawing.Size(300,25)
$form.Controls.Add($targetBox)

$btnDiag = New-Object System.Windows.Forms.Button
$btnDiag.Text="一键诊断"
$btnDiag.Location=New-Object System.Drawing.Point(30,235)
$btnDiag.Size=New-Object System.Drawing.Size(150,42)
$form.Controls.Add($btnDiag)

$btnFix = New-Object System.Windows.Forms.Button
$btnFix.Text="一键修复 Reconnecting"
$btnFix.Location=New-Object System.Drawing.Point(195,235)
$btnFix.Size=New-Object System.Drawing.Size(180,42)
$form.Controls.Add($btnFix)

$btnMigrate = New-Object System.Windows.Forms.Button
$btnMigrate.Text="迁移 .codex"
$btnMigrate.Location=New-Object System.Drawing.Point(390,235)
$btnMigrate.Size=New-Object System.Drawing.Size(140,42)
$form.Controls.Add($btnMigrate)

$btnRestore = New-Object System.Windows.Forms.Button
$btnRestore.Text="恢复到 C 盘"
$btnRestore.Location=New-Object System.Drawing.Point(545,235)
$btnRestore.Size=New-Object System.Drawing.Size(140,42)
$form.Controls.Add($btnRestore)

$btnDoctor = New-Object System.Windows.Forms.Button
$btnDoctor.Text="运行 codex doctor"
$btnDoctor.Location=New-Object System.Drawing.Point(700,235)
$btnDoctor.Size=New-Object System.Drawing.Size(150,42)
$form.Controls.Add($btnDoctor)

$script:LogBox = New-Object System.Windows.Forms.TextBox
$script:LogBox.Multiline=$true
$script:LogBox.ScrollBars="Vertical"
$script:LogBox.ReadOnly=$true
$script:LogBox.Font=New-Object System.Drawing.Font("Consolas",9)
$script:LogBox.Location=New-Object System.Drawing.Point(30,300)
$script:LogBox.Size=New-Object System.Drawing.Size(820,300)
$script:LogBox.Anchor="Top,Bottom,Left,Right"
$form.Controls.Add($script:LogBox)

$status = New-Object System.Windows.Forms.Label
$status.Text="提示：修改 ~/.codex/.env 后，需要彻底退出并重新打开 ChatGPT/Codex Desktop。"
$status.Location=New-Object System.Drawing.Point(30,612)
$status.Size=New-Object System.Drawing.Size(820,25)
$status.Anchor="Bottom,Left,Right"
$form.Controls.Add($status)

$btnDiag.Add_Click({
    try {
        Add-Log "=== Diagnostics ==="
        Update-Status
        $sys=Get-SystemProxy
        Add-Log "Windows proxy: enabled=$($sys.Enabled) server=$($sys.Server)"
        foreach($c in @(Get-ProxyCandidates)){
            Add-Log "Candidate $($c.Port) | process=$($c.Process) | HTTP=$($c.HttpOk) | source=$($c.Source)"
        }
        if(Test-Path (Join-Path $CodexDir ".env")){Add-Log ".env exists."} else {Add-Log ".env not found."}
        Add-Log "Log: $LogFile"
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"Codex Doctor")
        Add-Log "ERROR: $($_.Exception.Message)"
    }
})

$btnFix.Add_Click({
    try {
        Stop-CodexProcesses
        $p=Write-CodexProxy
        Update-Status
        [System.Windows.Forms.MessageBox]::Show(
            "修复完成。`n代理：http://127.0.0.1:$($p.Port)`n`n请重新打开 ChatGPT/Codex Desktop。",
            "Codex Doctor"
        )
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"修复失败")
        Add-Log "ERROR: $($_.Exception.Message)"
    }
})

$btnMigrate.Add_Click({
    try {
        $rootPath=$targetBox.Text.Trim()
        if([string]::IsNullOrWhiteSpace($rootPath)){throw "请输入迁移目标，例如 D:\Codex"}
        $ans=[System.Windows.Forms.MessageBox]::Show(
            "将 $CodexDir 迁移到 $rootPath\.codex，并创建 NTFS Junction。`n原数据会保留备份。是否继续？",
            "确认迁移",
            [System.Windows.Forms.MessageBoxButtons]::YesNo
        )
        if($ans -eq [System.Windows.Forms.DialogResult]::Yes){
            Migrate-Codex $rootPath
            Update-Status
            [System.Windows.Forms.MessageBox]::Show("迁移完成。","Codex Doctor")
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"迁移失败")
        Add-Log "ERROR: $($_.Exception.Message)"
    }
})

$btnRestore.Add_Click({
    try {
        $ans=[System.Windows.Forms.MessageBox]::Show(
            "恢复 .codex 到用户目录，并解除 Junction。是否继续？",
            "确认恢复",
            [System.Windows.Forms.MessageBoxButtons]::YesNo
        )
        if($ans -eq [System.Windows.Forms.DialogResult]::Yes){
            Restore-Codex
            Update-Status
            [System.Windows.Forms.MessageBox]::Show("恢复完成。","Codex Doctor")
        }
    } catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"恢复失败")
        Add-Log "ERROR: $($_.Exception.Message)"
    }
})

$btnDoctor.Add_Click({
    try { Run-CodexDoctor }
    catch {
        [System.Windows.Forms.MessageBox]::Show($_.Exception.Message,"Codex Doctor")
        Add-Log "ERROR: $($_.Exception.Message)"
    }
})

$form.Add_Shown({
    try { Update-Status } catch { Add-Log "Initial status failed: $($_.Exception.Message)" }
})

[void]$form.ShowDialog()
