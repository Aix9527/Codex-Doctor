﻿@echo off
chcp 65001 >nul
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0Codex-Doctor-V4-GUI.ps1"
