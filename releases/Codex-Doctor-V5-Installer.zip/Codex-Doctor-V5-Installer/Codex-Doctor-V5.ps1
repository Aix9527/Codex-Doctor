﻿#requires -Version 5.1
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ErrorActionPreference = "Stop"
$ProgressPreference = "SilentlyContinue"

$AppVersion = "5.0.0"
$CodexDir = Join-Path $env:USERPROFILE ".codex"
$StateRoot = Join-Path $env:LOCALAPPDATA "CodexDoctorV5"
$StateFile = Join-Path $StateRoot "state.json"
$LogDir = Join-Path $StateRoot "logs"
$ReportDir = Join-Path $StateRoot "reports"
New-Item -ItemType Directory -Force -Path $StateRoot,$LogDir,$ReportDir | Out-Null
$LogFile = Join-Path $LogDir ("doctor-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".log")

function Add-Log([string]$Text) {
    $line = "[$(Get-Date -Format HH:mm:ss)] $Text"
    Add-Content -Path $LogFile -Value $line -Encoding UTF8
    if ($script:LogBox) {
        $script:LogBox.AppendText($line + [Environment]::NewLine)
        $script:LogBox.SelectionStart = $script:LogBox.Text.Length
        $script:LogBox.ScrollToCaret()
        [System.Windows.Forms.Application]::DoEvents()
    }
}

function Test-Admin {
    try {
        $id = [Security.Principal.WindowsIdentity]::GetCurrent()
        $p = New-Object Security.Principal.WindowsPrincipal($id)
        return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { return $false }
}

function Test-Port([int]$Port) {
    try {
        $c = New-Object Net.Sockets.TcpClient
        $ar = $c.BeginConnect("127.0.0.1",$Port,$null,$null)
        $ok = $ar.AsyncWaitHandle.WaitOne(350)
        if($ok -and $c.Connected){$c.EndConnect($ar);$c.Close();return $true}
        $c.Close()
    } catch {}
    return $false
}

function Get-ListenerProcess([int]$Port) {
    try {
        $x=Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction Stop|Select-Object -First 1
        if($x){
            $p=Get-Process -Id $x.OwningProcess -ErrorAction SilentlyContinue
            if($p){return $p.ProcessName}
        }
    }catch{}
    return ""
}

function Get-SystemProxy {
    try {
        $k=Get-ItemProperty "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
        [pscustomobject]@{
            Enabled=[bool]$k.ProxyEnable
            Server=$k.ProxyServer
            AutoConfigURL=$k.AutoConfigURL
        }
    } catch {
        [pscustomobject]@{Enabled=$false;Server="";AutoConfigURL=""}
    }
}

function Find-ClashConfigs {
    $roots=@(
        (Join-Path $env:APPDATA "io.github.clash-verge-rev.clash-verge-rev"),
        (Join-Path $env:APPDATA "clash-verge"),
        (Join-Path $env:APPDATA "Clash Verge"),
        (Join-Path $env:APPDATA "mihomo-party"),
        (Join-Path $env:USERPROFILE ".config\clash"),
        (Join-Path $env:USERPROFILE ".config\mihomo")
    ) | Where-Object {$_ -and (Test-Path $_)}

    $files=@()
    foreach($r in $roots){
        try{
            $files += Get-ChildItem $r -Recurse -File -ErrorAction SilentlyContinue |
                Where-Object {$_.Extension -in @(".yaml",".yml",".json")} |
                Select-Object -First 120
        }catch{}
    }
    $files
}

function Get-ProxyPortsFromConfig {
    $ports=@()
    foreach($f in Find-ClashConfigs){
        try{
            $txt=Get-Content $f.FullName -Raw
            foreach($key in @("mixed-port","port","socks-port")){
                foreach($x in [regex]::Matches($txt,"(?im)^\s*"+[regex]::Escape($key)+"\s*:\s*(\d+)")){
                    $ports += [pscustomobject]@{
                        Port=[int]$x.Groups[1].Value
                        Source="$key | $($f.FullName)"
                    }
                }
            }
        }catch{}
    }
    $ports | Sort-Object Port -Unique
}

function Test-HttpProxy([int]$Port) {
    foreach($u in @("https://chatgpt.com","https://api.openai.com")){
        try{
            $r=Invoke-WebRequest -Uri $u -Proxy "http://127.0.0.1:$Port" -Method Head -TimeoutSec 6 -UseBasicParsing
            if($r.StatusCode -ge 200 -and $r.StatusCode -lt 500){return $true}
        }catch{
            try{
                if($_.Exception.Response){
                    $code=[int]$_.Exception.Response.StatusCode
                    if($code -ge 400 -and $code -lt 500){return $true}
                }
            }catch{}
        }
    }
    return $false
}

function Get-ProxyCandidates {
    $raw=@()
    $sys=Get-SystemProxy

    if($sys.Enabled -and $sys.Server){
        foreach($m in [regex]::Matches($sys.Server,'(?:127\.0\.0\.1|localhost):(\d+)')){
            $raw += [pscustomobject]@{Port=[int]$m.Groups[1].Value;Source="Windows system proxy"}
        }
    }

    $raw += @(Get-ProxyPortsFromConfig)

    foreach($p in @(7897,7890,7891,10809,10808,1080,20171,20170)){
        $raw += [pscustomobject]@{Port=$p;Source="Common port scan"}
    }

    $seen=@{}
    $out=@()
    foreach($x in $raw){
        if($seen.ContainsKey($x.Port)){continue}
        $seen[$x.Port]=$true
        if(Test-Port $x.Port){
            $out += [pscustomobject]@{
                Port=$x.Port
                Source=$x.Source
                Process=(Get-ListenerProcess $x.Port)
                HttpOk=(Test-HttpProxy $x.Port)
            }
        }
    }

    $out | Sort-Object @{Expression="HttpOk";Descending=$true},Port
}

function Select-BestProxy {
    $c=@(Get-ProxyCandidates)
    if($c.Count -eq 0){return $null}
    $ok=@($c|Where-Object {$_.HttpOk})
    if($ok.Count){return $ok[0]}
    return $c[0]
}

function Backup-File([string]$Path){
    if(Test-Path $Path){
        $b="$Path.backup_$(Get-Date -Format yyyyMMdd_HHmmss)"
        Copy-Item $Path $b -Force
        return $b
    }
}

function Get-CodexProcesses {
    Get-Process -ErrorAction SilentlyContinue|Where-Object{
        $_.ProcessName -match 'Codex|ChatGPT' -or ($_.Path -and $_.Path -match 'Codex|ChatGPT')
    }
}

function Stop-CodexProcesses {
    $p=@(Get-CodexProcesses)
    if($p.Count){
        Add-Log "Closing Codex/ChatGPT processes..."
        $p|Stop-Process -Force -ErrorAction SilentlyContinue
        Start-Sleep -Milliseconds 800
    }
}

function Start-CodexDesktop {
    $started=$false

    foreach($candidate in @(
        (Join-Path $env:LOCALAPPDATA "Programs\ChatGPT\ChatGPT.exe"),
        (Join-Path $env:LOCALAPPDATA "Programs\Codex\Codex.exe")
    )){
        if(Test-Path $candidate){
            Start-Process $candidate
            Add-Log "Started: $candidate"
            $started=$true
            break
        }
    }

    if(-not $started){
        try{
            Start-Process "chatgpt:"
            Add-Log "Requested launch via chatgpt: protocol."
            $started=$true
        }catch{}
    }

    if(-not $started){
        try{
            Start-Process "shell:AppsFolder"
            Add-Log "Could not resolve app directly; opened AppsFolder."
        }catch{}
    }
}

function Write-CodexProxy {
    $p=Select-BestProxy
    if(-not $p){throw "No active local proxy found."}

    Add-Log "Selected proxy: 127.0.0.1:$($p.Port) | process=$($p.Process) | HTTP=$($p.HttpOk)"
    if(-not(Test-Path $CodexDir)){New-Item -ItemType Directory -Force -Path $CodexDir|Out-Null}

    $envfile=Join-Path $CodexDir ".env"
    $backup=Backup-File $envfile
    if($backup){Add-Log "Backup: $backup"}

    $old=@()
    if(Test-Path $envfile){$old=Get-Content $envfile -ErrorAction SilentlyContinue}
    $filtered=$old|Where-Object{
        $_ -notmatch '^\s*(HTTP_PROXY|HTTPS_PROXY|http_proxy|https_proxy|ALL_PROXY|all_proxy|NO_PROXY|no_proxy)\s*='
    }

    $url="http://127.0.0.1:$($p.Port)"
    $lines=@()
    if($filtered){$lines+=$filtered;$lines+=""}
    $lines+=@(
        "# Managed by Codex Doctor V5",
        "HTTP_PROXY=$url",
        "HTTPS_PROXY=$url",
        "http_proxy=$url",
        "https_proxy=$url",
        "NO_PROXY=localhost,127.0.0.1,::1",
        "no_proxy=localhost,127.0.0.1,::1"
    )
    Set-Content $envfile $lines -Encoding UTF8

    foreach($n in @("HTTP_PROXY","HTTPS_PROXY","http_proxy","https_proxy")){
        [Environment]::SetEnvironmentVariable($n,$url,"User")
    }
    foreach($n in @("NO_PROXY","no_proxy")){
        [Environment]::SetEnvironmentVariable($n,"localhost,127.0.0.1,::1","User")
    }

    Add-Log "Updated: $envfile"
    return $p
}

function Save-State($o){$o|ConvertTo-Json -Depth 5|Set-Content $StateFile -Encoding UTF8}
function Load-State {if(Test-Path $StateFile){Get-Content $StateFile -Raw|ConvertFrom-Json}else{$null}}

function Migrate-Codex([string]$Root){
    Stop-CodexProcesses
    New-Item -ItemType Directory -Force -Path $Root|Out-Null
    $target=Join-Path $Root ".codex"

    if(Test-Path $CodexDir){
        $i=Get-Item $CodexDir -Force
        if($i.Attributes -band [IO.FileAttributes]::ReparsePoint){throw "Codex directory is already linked."}
    }

    if((Test-Path $target) -and @(Get-ChildItem $target -Force -ErrorAction SilentlyContinue).Count -gt 0){
        throw "Target is not empty: $target"
    }

    New-Item -ItemType Directory -Force -Path $target|Out-Null
    $backup=$null

    if(Test-Path $CodexDir){
        Add-Log "Copying $CodexDir => $target"
        & robocopy $CodexDir $target /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /XJ /NFL /NDL /NP | Out-Null
        if($LASTEXITCODE -ge 8){throw "Robocopy failed: $LASTEXITCODE"}
        $backup="$CodexDir.pre-migrate-$(Get-Date -Format yyyyMMdd-HHmmss)"
        Move-Item $CodexDir $backup
    }

    cmd.exe /c "mklink /J `"$CodexDir`" `"$target`"" | Out-Null
    if(-not(Test-Path $CodexDir)){
        if($backup -and(Test-Path $backup)){Move-Item $backup $CodexDir}
        throw "Failed to create NTFS Junction."
    }

    Save-State ([ordered]@{
        source=$CodexDir
        target=$target
        backup=$backup
        migrated_at=(Get-Date).ToString("o")
    })

    Add-Log "Migration complete: $CodexDir => $target"
}

function Restore-Codex {
    Stop-CodexProcesses
    $s=Load-State
    if(-not $s){throw "No migration state found."}

    if(Test-Path $s.source){
        $i=Get-Item $s.source -Force
        if(-not($i.Attributes -band [IO.FileAttributes]::ReparsePoint)){
            throw "Source is not a Junction; aborting for safety."
        }
        cmd.exe /c "rmdir `"$($s.source)`"" | Out-Null
    }

    if($s.backup -and(Test-Path $s.backup)){
        Move-Item $s.backup $s.source
    } else {
        New-Item -ItemType Directory -Force -Path $s.source|Out-Null
    }

    if(Test-Path $s.target){
        & robocopy $s.target $s.source /E /COPY:DAT /DCOPY:DAT /R:2 /W:1 /XJ /NFL /NDL /NP | Out-Null
    }

    Remove-Item $StateFile -Force -ErrorAction SilentlyContinue
    Add-Log "Restore complete."
}

function Run-CodexDoctor {
    try {
        $null=Get-Command codex -ErrorAction Stop
        Add-Log "Running official codex doctor..."
        $out=& codex doctor 2>&1|Out-String
        Add-Log $out.Trim()
    } catch {
        Add-Log "Codex CLI not found in PATH."
    }
}

function Get-Health {
    $proxy=Select-BestProxy
    $codexExists=Test-Path $CodexDir
    $envExists=Test-Path (Join-Path $CodexDir ".env")
    $procCount=@(Get-CodexProcesses).Count

    $score=0
    if($codexExists){$score+=1}
    if($envExists){$score+=1}
    if($proxy){$score+=1}
    if($proxy -and $proxy.HttpOk){$score+=2}

    $level="Red"
    if($score -ge 4){$level="Green"}
    elseif($score -ge 2){$level="Yellow"}

    [pscustomobject]@{
        Level=$level
        Proxy=$proxy
        CodexExists=$codexExists
        EnvExists=$envExists
        ProcessCount=$procCount
    }
}

function Export-Report {
    $r=Join-Path $ReportDir ("CodexDoctorReport-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".txt")
    $h=Get-Health
    $sys=Get-SystemProxy
    $lines=@(
        "Codex Doctor V5 Report",
        "Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')",
        "Version: $AppVersion",
        "",
        "USERPROFILE: $env:USERPROFILE",
        "CodexDir: $CodexDir",
        "Admin: $(Test-Admin)",
        "Health: $($h.Level)",
        "CodexExists: $($h.CodexExists)",
        "EnvExists: $($h.EnvExists)",
        "CodexProcesses: $($h.ProcessCount)",
        "",
        "WindowsProxy.Enabled: $($sys.Enabled)",
        "WindowsProxy.Server: $($sys.Server)",
        "WindowsProxy.PAC: $($sys.AutoConfigURL)",
        ""
    )

    $c=@(Get-ProxyCandidates)
    if($c.Count){
        $lines+="Proxy candidates:"
        foreach($x in $c){
            $lines+="  Port=$($x.Port) Process=$($x.Process) HTTP=$($x.HttpOk) Source=$($x.Source)"
        }
    } else {
        $lines+="Proxy candidates: none"
    }

    $lines+=""; $lines+="LogFile: $LogFile"
    Set-Content $r $lines -Encoding UTF8
    Add-Log "Report exported: $r"
    Start-Process explorer.exe "/select,`"$r`""
}

# ---------- GUI ----------
$form=New-Object Windows.Forms.Form
$form.Text="Codex Doctor V5"
$form.Size=New-Object Drawing.Size(960,730)
$form.StartPosition="CenterScreen"
$form.MinimumSize=New-Object Drawing.Size(900,680)

$title=New-Object Windows.Forms.Label
$title.Text="Codex Doctor V5"
$title.Font=New-Object Drawing.Font("Segoe UI",21,[Drawing.FontStyle]::Bold)
$title.AutoSize=$true
$title.Location=New-Object Drawing.Point(28,18)
$form.Controls.Add($title)

$subtitle=New-Object Windows.Forms.Label
$subtitle.Text="Windows Codex / ChatGPT Desktop 健康检查、代理修复、数据迁移"
$subtitle.Location=New-Object Drawing.Point(32,61)
$subtitle.Size=New-Object Drawing.Size(850,25)
$form.Controls.Add($subtitle)

$healthPanel=New-Object Windows.Forms.Panel
$healthPanel.Location=New-Object Drawing.Point(30,95)
$healthPanel.Size=New-Object Drawing.Size(880,84)
$healthPanel.BorderStyle="FixedSingle"
$form.Controls.Add($healthPanel)

$script:HealthDot=New-Object Windows.Forms.Label
$script:HealthDot.Text="●"
$script:HealthDot.Font=New-Object Drawing.Font("Segoe UI",28,[Drawing.FontStyle]::Bold)
$script:HealthDot.Location=New-Object Drawing.Point(16,13)
$script:HealthDot.Size=New-Object Drawing.Size(50,55)
$healthPanel.Controls.Add($script:HealthDot)

$script:LblHealth=New-Object Windows.Forms.Label
$script:LblHealth.Font=New-Object Drawing.Font("Segoe UI",12,[Drawing.FontStyle]::Bold)
$script:LblHealth.Location=New-Object Drawing.Point(72,12)
$script:LblHealth.Size=New-Object Drawing.Size(770,25)
$healthPanel.Controls.Add($script:LblHealth)

$script:LblDetail=New-Object Windows.Forms.Label
$script:LblDetail.Location=New-Object Drawing.Point(72,43)
$script:LblDetail.Size=New-Object Drawing.Size(790,28)
$healthPanel.Controls.Add($script:LblDetail)

$targetLabel=New-Object Windows.Forms.Label
$targetLabel.Text="迁移目标："
$targetLabel.Location=New-Object Drawing.Point(32,196)
$targetLabel.Size=New-Object Drawing.Size(80,25)
$form.Controls.Add($targetLabel)

$targetBox=New-Object Windows.Forms.TextBox
$targetBox.Text="D:\Codex"
$targetBox.Location=New-Object Drawing.Point(112,193)
$targetBox.Size=New-Object Drawing.Size(310,25)
$form.Controls.Add($targetBox)

$btnNames=@(
    @("一键诊断",30,235,135),
    @("修复 Reconnecting",175,235,165),
    @("迁移 .codex",350,235,135),
    @("恢复到 C 盘",495,235,135),
    @("重启 Codex",640,235,125),
    @("导出报告",775,235,135)
)
$buttons=@{}
foreach($b in $btnNames){
    $btn=New-Object Windows.Forms.Button
    $btn.Text=$b[0]
    $btn.Location=New-Object Drawing.Point($b[1],$b[2])
    $btn.Size=New-Object Drawing.Size($b[3],42)
    $form.Controls.Add($btn)
    $buttons[$b[0]]=$btn
}

$btnDoctor=New-Object Windows.Forms.Button
$btnDoctor.Text="运行 codex doctor"
$btnDoctor.Location=New-Object Drawing.Point(30,288)
$btnDoctor.Size=New-Object Drawing.Size(170,38)
$form.Controls.Add($btnDoctor)

$btnRefresh=New-Object Windows.Forms.Button
$btnRefresh.Text="刷新健康状态"
$btnRefresh.Location=New-Object Drawing.Point(212,288)
$btnRefresh.Size=New-Object Drawing.Size(150,38)
$form.Controls.Add($btnRefresh)

$script:AdminLabel=New-Object Windows.Forms.Label
$script:AdminLabel.Location=New-Object Drawing.Point(385,296)
$script:AdminLabel.Size=New-Object Drawing.Size(400,24)
$form.Controls.Add($script:AdminLabel)

$script:LogBox=New-Object Windows.Forms.TextBox
$script:LogBox.Multiline=$true
$script:LogBox.ScrollBars="Vertical"
$script:LogBox.ReadOnly=$true
$script:LogBox.Font=New-Object Drawing.Font("Consolas",9)
$script:LogBox.Location=New-Object Drawing.Point(30,345)
$script:LogBox.Size=New-Object Drawing.Size(880,300)
$script:LogBox.Anchor="Top,Bottom,Left,Right"
$form.Controls.Add($script:LogBox)

$footer=New-Object Windows.Forms.Label
$footer.Text="V5 会保留备份；修改代理后请彻底退出并重新打开 Codex / ChatGPT Desktop。"
$footer.Location=New-Object Drawing.Point(30,660)
$footer.Size=New-Object Drawing.Size(880,25)
$footer.Anchor="Bottom,Left,Right"
$form.Controls.Add($footer)

function Refresh-HealthUI {
    $script:LblHealth.Text="正在检查..."
    [Windows.Forms.Application]::DoEvents()
    $h=Get-Health

    switch($h.Level){
        "Green" {
            $script:HealthDot.ForeColor=[Drawing.Color]::ForestGreen
            $script:LblHealth.Text="健康状态：正常"
        }
        "Yellow" {
            $script:HealthDot.ForeColor=[Drawing.Color]::DarkOrange
            $script:LblHealth.Text="健康状态：需要检查"
        }
        default {
            $script:HealthDot.ForeColor=[Drawing.Color]::Firebrick
            $script:LblHealth.Text="健康状态：存在连接问题"
        }
    }

    if($h.Proxy){
        $script:LblDetail.Text="代理 127.0.0.1:$($h.Proxy.Port) | $($h.Proxy.Process) | HTTP=$($h.Proxy.HttpOk) | .env=$($h.EnvExists)"
    } else {
        $script:LblDetail.Text="未发现可用本地代理 | .env=$($h.EnvExists)"
    }

    $script:AdminLabel.Text="管理员权限：" + $(if(Test-Admin){"是"}else{"否（迁移 Junction 时可能需要提升权限）"})
}

$buttons["一键诊断"].Add_Click({
    try{
        Add-Log "=== Full diagnostics ==="
        Refresh-HealthUI
        $sys=Get-SystemProxy
        Add-Log "Windows proxy: enabled=$($sys.Enabled) server=$($sys.Server)"
        foreach($c in @(Get-ProxyCandidates)){
            Add-Log "Proxy $($c.Port) | process=$($c.Process) | HTTP=$($c.HttpOk) | $($c.Source)"
        }
        Add-Log "CodexDir: $CodexDir"
        Add-Log "Log: $LogFile"
    }catch{
        Add-Log "ERROR: $($_.Exception.Message)"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message,"诊断失败")
    }
})

$buttons["修复 Reconnecting"].Add_Click({
    try{
        Stop-CodexProcesses
        $p=Write-CodexProxy
        Refresh-HealthUI
        [Windows.Forms.MessageBox]::Show(
            "代理已修复：`nhttp://127.0.0.1:$($p.Port)`n`n现在可以重新启动 Codex / ChatGPT Desktop。",
            "Codex Doctor V5"
        )
    }catch{
        Add-Log "ERROR: $($_.Exception.Message)"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message,"修复失败")
    }
})

$buttons["迁移 .codex"].Add_Click({
    try{
        $root=$targetBox.Text.Trim()
        if([string]::IsNullOrWhiteSpace($root)){throw "请输入目标目录，例如 D:\Codex"}
        $ans=[Windows.Forms.MessageBox]::Show(
            "即将迁移：`n$CodexDir`n→`n$root\.codex`n`n原数据会保留备份。是否继续？",
            "确认迁移",
            [Windows.Forms.MessageBoxButtons]::YesNo
        )
        if($ans -eq [Windows.Forms.DialogResult]::Yes){
            Migrate-Codex $root
            Refresh-HealthUI
            [Windows.Forms.MessageBox]::Show("迁移完成。","Codex Doctor V5")
        }
    }catch{
        Add-Log "ERROR: $($_.Exception.Message)"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message,"迁移失败")
    }
})

$buttons["恢复到 C 盘"].Add_Click({
    try{
        $ans=[Windows.Forms.MessageBox]::Show(
            "将解除 Junction 并恢复 .codex 到用户目录。是否继续？",
            "确认恢复",
            [Windows.Forms.MessageBoxButtons]::YesNo
        )
        if($ans -eq [Windows.Forms.DialogResult]::Yes){
            Restore-Codex
            Refresh-HealthUI
            [Windows.Forms.MessageBox]::Show("恢复完成。","Codex Doctor V5")
        }
    }catch{
        Add-Log "ERROR: $($_.Exception.Message)"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message,"恢复失败")
    }
})

$buttons["重启 Codex"].Add_Click({
    try{
        Stop-CodexProcesses
        Start-Sleep -Seconds 1
        Start-CodexDesktop
    }catch{
        Add-Log "ERROR: $($_.Exception.Message)"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message,"重启失败")
    }
})

$buttons["导出报告"].Add_Click({
    try{Export-Report}catch{
        Add-Log "ERROR: $($_.Exception.Message)"
        [Windows.Forms.MessageBox]::Show($_.Exception.Message,"导出失败")
    }
})

$btnDoctor.Add_Click({
    try{Run-CodexDoctor}catch{
        Add-Log "ERROR: $($_.Exception.Message)"
    }
})

$btnRefresh.Add_Click({
    try{Refresh-HealthUI}catch{
        Add-Log "ERROR: $($_.Exception.Message)"
    }
})

$form.Add_Shown({
    Refresh-HealthUI
    Add-Log "Codex Doctor V5 started."
})

[void]$form.ShowDialog()
