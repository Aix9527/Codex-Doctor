# Codex Doctor V5 — Installer Edition

这是 V4 GUI 的长期使用版。

## 新增功能
- 健康状态灯：绿色 / 黄色 / 红色。
- 管理员权限检测。
- 一键诊断。
- 一键修复 Codex / ChatGPT Desktop Reconnecting。
- 自动读取 Windows 系统代理。
- 自动解析 Clash Verge / Clash Verge Rev / Mihomo 的：
  - mixed-port
  - port
  - socks-port
- 对候选代理做真实 HTTPS 测试。
- 自动修改 `%USERPROFILE%\.codex\.env`。
- 自动写入用户级 HTTP_PROXY / HTTPS_PROXY。
- 一键迁移 `.codex` 到 D/E 盘。
- NTFS Junction 保持原路径兼容。
- 一键恢复到 C 盘。
- 一键重启 Codex / ChatGPT Desktop。
- 可运行官方 `codex doctor`。
- 一键导出诊断报告。
- 安装到 `%LOCALAPPDATA%\Programs\CodexDoctorV5`。
- 自动创建桌面快捷方式和开始菜单快捷方式。
- 提供卸载脚本。

## 安装
双击：

`安装_Codex_Doctor_V5.bat`

安装完成后桌面会出现：

`Codex Doctor V5`

## 推荐第一次使用
1. 点击“一键诊断”
2. 看健康状态灯
3. 如果是黄色/红色，点击“修复 Reconnecting”
4. 点击“重启 Codex”
5. 如需节省 C 盘空间，再把 `.codex` 迁移到 `D:\Codex`

## 关于 EXE
本包采用 PowerShell + WinForms，避免依赖未安装的第三方打包器。
如果你需要真正的单文件 `CodexDoctor.exe`，可在 Windows 上安装 PS2EXE 后执行 Build-EXE.ps1。
