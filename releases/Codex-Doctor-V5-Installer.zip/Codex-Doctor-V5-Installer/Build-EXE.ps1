﻿# Optional EXE build helper for Windows
# Requires the PS2EXE PowerShell module.
$ErrorActionPreference="Stop"

if(-not (Get-Module -ListAvailable -Name ps2exe)){
    Write-Host "PS2EXE module is not installed." -ForegroundColor Yellow
    Write-Host "Install it first in an elevated PowerShell:"
    Write-Host "Install-Module ps2exe -Scope CurrentUser"
    exit 1
}

Import-Module ps2exe
$src = Join-Path $PSScriptRoot "Codex-Doctor-V5.ps1"
$out = Join-Path $PSScriptRoot "CodexDoctorV5.exe"

Invoke-ps2exe `
    -inputFile $src `
    -outputFile $out `
    -noConsole `
    -STA `
    -title "Codex Doctor V5" `
    -product "Codex Doctor V5" `
    -version "5.0.0.0"

Write-Host "Built: $out" -ForegroundColor Green
