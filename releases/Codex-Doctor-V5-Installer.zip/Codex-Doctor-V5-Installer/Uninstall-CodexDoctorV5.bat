﻿@echo off
chcp 65001 >nul
title Uninstall Codex Doctor V5

set "APPDIR=%LOCALAPPDATA%\Programs\CodexDoctorV5"
del /Q "%USERPROFILE%\Desktop\Codex Doctor V5.lnk" 2>nul
del /Q "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Codex Doctor V5.lnk" 2>nul

echo.
echo Removing application files...
timeout /t 1 >nul
cd /d "%TEMP%"
rmdir /S /Q "%APPDIR%" 2>nul

echo.
echo Codex Doctor V5 application files removed.
echo Diagnostic logs remain under:
echo %LOCALAPPDATA%\CodexDoctorV5
echo.
pause
