﻿@echo off
chcp 65001 >nul
title Install Codex Doctor V5

set "APPDIR=%LOCALAPPDATA%\Programs\CodexDoctorV5"
if not exist "%APPDIR%" mkdir "%APPDIR%"

copy /Y "%~dp0Codex-Doctor-V5.ps1" "%APPDIR%\Codex-Doctor-V5.ps1" >nul
copy /Y "%~dp0Launch-CodexDoctorV5.bat" "%APPDIR%\Launch-CodexDoctorV5.bat" >nul
copy /Y "%~dp0Uninstall-CodexDoctorV5.bat" "%APPDIR%\Uninstall-CodexDoctorV5.bat" >nul

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
"$ws = New-Object -ComObject WScript.Shell; ^
$desk = [Environment]::GetFolderPath('Desktop'); ^
$lnk = $ws.CreateShortcut((Join-Path $desk 'Codex Doctor V5.lnk')); ^
$lnk.TargetPath = '%APPDIR%\Launch-CodexDoctorV5.bat'; ^
$lnk.WorkingDirectory = '%APPDIR%'; ^
$lnk.Save(); ^
$start = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Codex Doctor V5.lnk'; ^
$lnk2 = $ws.CreateShortcut($start); ^
$lnk2.TargetPath = '%APPDIR%\Launch-CodexDoctorV5.bat'; ^
$lnk2.WorkingDirectory = '%APPDIR%'; ^
$lnk2.Save();"

echo.
echo Codex Doctor V5 installed:
echo %APPDIR%
echo.
start "" "%APPDIR%\Launch-CodexDoctorV5.bat"
pause
