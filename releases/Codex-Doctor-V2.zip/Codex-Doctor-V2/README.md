# Codex Doctor V2

用途：Windows 上修复 Codex Desktop / ChatGPT Desktop Codex 模式常见的代理与 `Reconnecting` 问题，并把 `%USERPROFILE%\.codex` 迁移到 D/E 盘。

## 设计原则

- **不强行迁移 Microsoft Store / MSIX 安装的应用本体。**
- 默认只迁移 `%USERPROFILE%\.codex`，这是更稳定、升级风险更低的做法。
- 迁移方式为 NTFS Junction，因此 Codex 仍访问原来的 `%USERPROFILE%\.codex` 路径。
- 修改 `.env` 前自动备份。
- 迁移前自动关闭 Codex / ChatGPT 相关进程。
- 保留迁移状态，可一键恢复。
- 支持调用官方 `codex doctor`（如果 CLI 已在 PATH 中）。

## 使用

双击：

`运行_Codex_Doctor_V2.bat`

然后选择：

1. Diagnose
2. Fix Codex proxy / Reconnecting
3. Migrate ~/.codex to another drive
4. Restore ~/.codex to C: profile
5. Run official codex doctor
6. Diagnose + proxy fix + codex doctor

默认迁移目标：

`D:\Codex\.codex`

也可以在菜单里输入：

`E:\Codex`

## 代理检测

当前会优先读取 Windows 系统代理，再扫描：

- 7897
- 7890
- 7891
- 10809
- 10808
- 1080
- 20171
- 20170

找到有效本地监听后，会写入：

`%USERPROFILE%\.codex\.env`

包含：

- `HTTP_PROXY`
- `HTTPS_PROXY`
- `http_proxy`
- `https_proxy`
- `NO_PROXY`
- `no_proxy`

## 关于应用本体迁移

不建议手工搬运 Windows Store/MSIX 的 ChatGPT/Codex 安装目录或 `WindowsApps` 内容。
应用本体由 Windows 包管理机制维护，强行移动容易影响更新、权限和修复。

本工具迁移的是 Codex 用户数据目录，这通常才是更适合转移到 D/E 盘的部分。

## 回滚

菜单选择 `4`。

迁移状态保存在：

`%LOCALAPPDATA%\CodexDoctorV2\state.json`

日志：

`%LOCALAPPDATA%\CodexDoctorV2\logs\`

## 注意

修改代理或 `.env` 后，请彻底退出 ChatGPT/Codex Desktop（包括后台进程）再重新打开。
