# Codex Doctor V3 — Smart Proxy Edition

## 新增
- 读取 Clash Verge / Clash Verge Rev / Mihomo 常见配置目录。
- 自动识别 `mixed-port` / `port` / `socks-port`。
- 同时读取 Windows 系统代理。
- 对候选 HTTP 代理做真实 HTTPS 请求测试，而不仅仅看端口是否监听。
- 自动选择更可信的代理端口写入 `%USERPROFILE%\.codex\.env`。
- 保留 V2 的 `.codex` D/E 盘迁移、Junction、备份和一键恢复。
- 若 `codex` CLI 在 PATH 中，可调用官方 `codex doctor`。

## 推荐首次使用
1. 双击 `运行_Codex_Doctor_V3.bat`
2. 先选 `1 Diagnose`
3. 再选 `3 One-click AutoFix`
4. 如需节省 C 盘，再选 `4`，目标例如 `D:\Codex`
5. 完全退出并重新打开 ChatGPT/Codex Desktop

## 默认识别配置目录
- `%APPDATA%\io.github.clash-verge-rev.clash-verge-rev`
- `%APPDATA%\clash-verge`
- `%APPDATA%\Clash Verge`
- `%APPDATA%\mihomo-party`
- `%USERPROFILE%\.config\clash`
- `%USERPROFILE%\.config\mihomo`

## 安全策略
- 不修改 WindowsApps / MSIX 应用包。
- 不删除原 `.codex`，迁移时先保留备份。
- `.env` 修改前自动备份。
- 迁移失败时尝试自动回滚。
